from django.db import models

class Files(models.Model):
    filename = models.CharField(max_length=50)
    cont=models.FileField(upload_to='files/')
    descr=models.TextField(blank=True)
    downCount=models.IntegerField()

    def getDescription(self):
        return self.descr
    #def __str__(self):
     #   return self.filename

    class Meta:
        verbose_name = 'Файл'
        verbose_name_plural = 'Файлы'
        ordering = ['-filename']